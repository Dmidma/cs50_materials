<p>
	A share of <?= print($stock["name"]) ?>. (<?= print($stock["symbol"]) ?>) costs <b>$<?= print(number_format($stock["price"], 2, "." ,",")) ?></b>.
</p>
